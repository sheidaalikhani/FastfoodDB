# fastfoodDB
Simple fastfood Database
